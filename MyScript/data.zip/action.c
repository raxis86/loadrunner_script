Action()
{

	lr_think_time(36);

	web_submit_data("quiz_2", 
		"Action=http://wiley.youplace.net/quiz", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://wiley.youplace.net/quiz", 
		"Snapshot=t444.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=name", "Value=user1", ENDITEM, 
		"Name=password", "Value=test", ENDITEM, 
		"Name=__timestamp", "Value=1486411206", ENDITEM, 
		"Name=__secret", "Value=f0f8720dfde74d31e999d5aef84841ee37c5bc0d37d75841a13531b609c7a8a6", ENDITEM, 
		EXTRARES, 
		"Url=/img/system/ajax-loader.gif", ENDITEM, 
		LAST);

	web_url("1", 
		"URL=http://wiley.youplace.net/quiz/question/1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://wiley.youplace.net/quiz", 
		"Snapshot=t445.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(9);

	web_submit_data("1_2", 
		"Action=http://wiley.youplace.net/quiz/question/1", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://wiley.youplace.net/quiz/question/1", 
		"Snapshot=t446.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=kko8mhuclrl", "Value=large text", ENDITEM, 
		"Name=8dsqus9f66e5jtd0m", "Value=1", ENDITEM, 
		"Name=66ttno58gql3zzvq", "Value=2", ENDITEM, 
		"Name=__timestamp", "Value=1486411251", ENDITEM, 
		"Name=__secret", "Value=afab2ffbd0d9043913fb039baef4214c91dcaa5c0f12d77ef146310e9f32f19a", ENDITEM, 
		LAST);

	web_url("2", 
		"URL=http://wiley.youplace.net/quiz/question/2", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://wiley.youplace.net/quiz/question/1", 
		"Snapshot=t447.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(7);

	web_custom_request("query", 
		"URL=https://clients1.google.com/tbproxy/af/query?client=Google%20Chrome", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/proto", 
		"Referer=", 
		"Snapshot=t448.inf", 
		"Mode=HTML", 
		"EncType=text/proto", 
		"BodyBinary=\n\\x176.1.1715.1442/en (GGLL)\\x13\\x19\\xBE)\\x83\\x1DN\\xE0\\x91\\xB9#-\"r\\xA0\\xF1$#-\\xF7q\\x04\\xB6$#-\\xB1 \\xBCG$#-\\xE9fo\\xED$\\x14", 
		LAST);

	lr_think_time(9);

	web_submit_data("2_2", 
		"Action=http://wiley.youplace.net/quiz/question/2", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=http://wiley.youplace.net/quiz/question/2", 
		"Snapshot=t449.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=8u5n0ohdp4uab144osax", "Value=3", ENDITEM, 
		"Name=ib0h7ravqj", "Value=1", ENDITEM, 
		"Name=7qko4aszk30o7ohilpj", "Value=3", ENDITEM, 
		"Name=jl8aw41fux", "Value=short text", ENDITEM, 
		"Name=ibpt4oe7p3fdkxz9", "Value=3", ENDITEM, 
		"Name=__timestamp", "Value=1486411260", ENDITEM, 
		"Name=__secret", "Value=3a2fd8da7745a632f6400ec568235a6e369dbe900c372c69fb9f8e93b49baa29", ENDITEM, 
		LAST);

	web_url("3", 
		"URL=http://wiley.youplace.net/quiz/question/3", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://wiley.youplace.net/quiz/question/2", 
		"Snapshot=t450.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}